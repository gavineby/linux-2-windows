<?php

use App\Models\Replies;
use App\Models\Discussion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//Show All Posts
Route::get('/', function () {
    return view('index', [
        'discussions' => Discussion::all()->sortByDesc('created_at')->take(10)
    ]);
});

//Show Single Post/Search
Route::get('/blogs', function (Request $request) {
    return view ('blog', [
        'discid' => $request->id,
        'replies' => Replies::all()->where("discussion_id", "=", $request->id),
        'discussion' => Discussion::all()->where("id", "=", $request->id)
    ]);
});

//Create Post
Route::get('/post', function () {
    return view('post');
});