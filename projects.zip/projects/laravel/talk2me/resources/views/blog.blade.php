@extends('layout')

@section('content')
    
    {{-- Showcase --}}
    <section class="p-5 bg-dark text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1 class="text-light fw-bold">Read a Blog</h1>
                </div>

                <img src="img/blog.svg" alt="" class="img-fluid w-50 d-none d-sm-block">
            </div>
        </div>
    </section>

    {{-- Singular Post --}}
    <section class="p-5 bg-light">
        <div class="container">

            <form class="input-group my-2" method="get" autocomplete="off">
                <textarea style="resize: none; height: 100px;" class="form-control" name="myreply" placeholder="Reply"></textarea><button class="btn btn-primary" name="submit" value="{{$discid}}">Submit</button>
            </form>

            @foreach ($discussion as $disc)
                <div class="row g-2">
                    <div class="col-md">
                        <div class="card">
                            <div class="card-body">
                                <a href="/blogs?id={{$disc->id}}" style="text-decoration: none">
                                    <div class="card-title text-dark">
                                        <h5 class="mb-3 fw-bold">{{$disc->title}}</h5>
                                        {{$disc->body}}
                                    </div>
                                    <div class="card-text text-primary">
                                        {{$disc->user}} - <span class="fw-bold">Id: {{$disc->id}}</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
            
            @if (empty($disc['id']))
                <script>
                    window.location = "/";
                </script>
            @endif

            <div class="my-2">

                @foreach ($replies as $reply)
                    <div class="row my-2">
                        <div class="col-md">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title text-dark text-truncate">
                                        {{$reply->body}}
                                    </div>
                                    <div class="card-text text-primary text-truncate">
                                        {{$reply->user}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                
            </div>

            @php
                // Creating reply
                if (isset($_GET['submit'])) {
                    $myreply = $_GET['myreply'];
                    $disc_id = $_GET['submit'];
                    if (!empty($myreply)) {
                        DB::table('replies')->insert(['discussion_id' => $disc_id, 'body' => $myreply, 'user' => 'Guest']);
                    }
                }
            @endphp

        </div>
    </section>

@endsection