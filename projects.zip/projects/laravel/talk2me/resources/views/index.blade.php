@extends('layout')

@section('content')

    {{-- Showcase --}}
    <section class="p-5 bg-dark text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1 class="text-light fw-bold">talk2me Blogs</h1>
                </div>

                <img src="img/index.svg" alt="" class="img-fluid w-50 d-none d-sm-block">
            </div>
        </div>
    </section>

    {{-- Search --}}
    <section class="p-4 bg-dark">
        <div class="container">
            <form class="input-group" action="/blogs" method="get" autocomplete="off">
                <input class="form-control" type="text" name="id" placeholder="Search by Id"><button class="btn btn-primary">Search</button>
            </form>
        </div>
    </section>

    {{-- Discussions --}}
    <section class="p-5 bg-light">
        <div class="container">
            <div class="row g-2">
                @foreach ($discussions as $disc)
                    <div class="col-md">
                        <div class="card">
                            <div class="card-body">
                                <a href="/blogs?id={{$disc->id}}" style="text-decoration: none">
                                    <div class="card-title text-dark text-truncate">
                                        <h5 class="mb-3 fw-bold">{{$disc->title}}</h5>
                                        {{$disc->body}}
                                    </div>
                                    <div class="card-text text-primary text-truncate">
                                        {{$disc->user}} - <span class="fw-bold">Id: {{$disc->id}}</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

    <footer class="text-center text-secondary">Copyright &copy; talk2me 2022</footer>

@endsection