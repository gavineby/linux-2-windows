<?php $__env->startSection('content'); ?>

    
    <section class="p-5 bg-dark text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1 class="text-light fw-bold">talk2me Blogs</h1>
                </div>

                <img src="img/index.svg" alt="" class="img-fluid w-50 d-none d-sm-block">
            </div>
        </div>
    </section>

    
    <section class="p-4 bg-dark">
        <div class="container">
            <form class="input-group" action="/blogs" method="get" autocomplete="off">
                <input class="form-control" type="text" name="id" placeholder="Search by Id"><button class="btn btn-primary">Search</button>
            </form>
        </div>
    </section>

    
    <section class="p-5 bg-light">
        <div class="container">
            <div class="row g-2">
                <?php $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md">
                        <div class="card">
                            <div class="card-body">
                                <a href="/blogs?id=<?php echo e($disc->id); ?>" style="text-decoration: none">
                                    <div class="card-title text-dark text-truncate">
                                        <h5 class="mb-3 fw-bold"><?php echo e($disc->title); ?></h5>
                                        <?php echo e($disc->body); ?>

                                    </div>
                                    <div class="card-text text-primary text-truncate">
                                        <?php echo e($disc->user); ?> - <span class="fw-bold">Id: <?php echo e($disc->id); ?></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <footer class="text-center text-secondary">Copyright &copy; talk2me 2022</footer>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gavineby/Desktop/projects/laravel/talk2me/resources/views/index.blade.php ENDPATH**/ ?>