<?php $__env->startSection('content'); ?>
    
    <div class="about">
        <p>talk2me is a Discussion Page. Ask any Question you Feel Like, and get a Response From Others!</p>
        <a href="https://gavineby.netlify.app" target="_blank">My Web Developer Portfolio if you are Interested in More!</a>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gavineby/Desktop/projects/talk2me/resources/views/about.blade.php ENDPATH**/ ?>