<?php $__env->startSection('content'); ?>
    
    <div class="post-container">

        <?php $__currentLoopData = $singlePost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-post">
                <h2 class="user"><?php echo e($post['user']); ?></h2>
                <p class="body"><?php echo e($post['body']); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(empty($post['id'])): ?>
            <script>
                window.location = "/";
            </script>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gavineby/Desktop/projects/talk2me/resources/views/singlePost.blade.php ENDPATH**/ ?>