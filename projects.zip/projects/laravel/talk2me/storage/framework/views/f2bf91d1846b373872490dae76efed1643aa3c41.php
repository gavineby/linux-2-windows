<?php $__env->startSection('content'); ?>
    
    <?php
        $title = $_GET['title'];
        $body = $_GET['body'];
        if (!empty($body)) {
            DB::table('discussions')->insert([ 'user' => 'Guest', 'title' => $title, 'body' => $body]);
            echo $discussion;
        } else {
            echo "<script>window.location = '/';</script>";
        }
    ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gavineby/Desktop/projects/talk2me/resources/views/posted.blade.php ENDPATH**/ ?>