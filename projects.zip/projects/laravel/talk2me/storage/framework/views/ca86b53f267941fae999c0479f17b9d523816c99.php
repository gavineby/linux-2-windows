<?php $__env->startSection('content'); ?>
    
    
    <section class="p-5 bg-dark text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1 class="text-light fw-bold">Read a Blog</h1>
                </div>

                <img src="img/blog.svg" alt="" class="img-fluid w-50 d-none d-sm-block">
            </div>
        </div>
    </section>

    
    <section class="p-5 bg-light">
        <div class="container">

            <form class="input-group my-2" method="get" autocomplete="off">
                <textarea style="resize: none; height: 100px;" class="form-control" name="myreply" placeholder="Reply"></textarea><button class="btn btn-primary" name="submit" value="<?php echo e($discid); ?>">Submit</button>
            </form>

            <?php $__currentLoopData = $discussion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row g-2">
                    <div class="col-md">
                        <div class="card">
                            <div class="card-body">
                                <a href="/blogs?id=<?php echo e($disc->id); ?>" style="text-decoration: none">
                                    <div class="card-title text-dark">
                                        <h5 class="mb-3 fw-bold"><?php echo e($disc->title); ?></h5>
                                        <?php echo e($disc->body); ?>

                                    </div>
                                    <div class="card-text text-primary">
                                        <?php echo e($disc->user); ?> - <span class="fw-bold">Id: <?php echo e($disc->id); ?></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(empty($disc['id'])): ?>
                <script>
                    window.location = "/";
                </script>
            <?php endif; ?>

            <div class="my-2">

                <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row my-2">
                        <div class="col-md">
                            <div class="card">
                                <div class="card-body">
                                    <div class="card-title text-dark text-truncate">
                                        <?php echo e($reply->body); ?>

                                    </div>
                                    <div class="card-text text-primary text-truncate">
                                        <?php echo e($reply->user); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>

            <?php
                // Creating reply
                if (isset($_GET['submit'])) {
                    $myreply = $_GET['myreply'];
                    $disc_id = $_GET['submit'];
                    if (!empty($myreply)) {
                        DB::table('replies')->insert(['discussion_id' => $disc_id, 'body' => $myreply, 'user' => 'Guest']);
                    }
                }
            ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gavineby/Desktop/projects/talk2me/resources/views/blog.blade.php ENDPATH**/ ?>