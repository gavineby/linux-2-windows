<?php $__env->startSection('content'); ?>

    
    <section class="p-5 bg-dark text-center text-sm-start">
        <div class="container">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h1 class="text-light fw-bold">Post a Blog</h1>
                </div>

                <img src="img/post.svg" alt="" class="img-fluid w-50 d-none d-sm-block">
            </div>
        </div>
    </section>

    
    <section class="p-5 bg-light">
        <div class="container">
            <form class="input-group" method="get" autocomplete="off">
                <textarea style="resize: none; height: 100px;" class="form-control" name="title" placeholder="Title"></textarea>
                <textarea style="resize: none; height: 100px;" class="form-control" name="body" placeholder="Body"></textarea><button class="btn btn-primary">Post</button>
            </form>
        </div>
    </section>

    <?php
        if (isset($_GET['body'])) {
            $title = $_GET['title'];
            $body = $_GET['body'];
            if (!empty($body)) {
                DB::table('discussions')->insert([ 'user' => 'Guest', 'title' => $title, 'body' => $body]);
            }
        }
    ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/gavineby/Desktop/projects/laravel/talk2me/resources/views/post.blade.php ENDPATH**/ ?>